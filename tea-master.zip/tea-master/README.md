# https://tea.xyz/what-is-this-file
---
version: 1.0.0
codeOwners:
  - '0x1CA79D4F17c057ACe25B4b36Efd1392Bee991dC0'
quorum: 1
